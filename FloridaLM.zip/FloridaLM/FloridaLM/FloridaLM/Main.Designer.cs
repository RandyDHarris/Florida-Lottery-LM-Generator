﻿namespace FloridaLM
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.dgPicks = new System.Windows.Forms.DataGridView();
            this.pNum1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNum2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNum3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNum4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pLB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pWinDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgHistory = new System.Windows.Forms.DataGridView();
            this.Num1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Num2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Num3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Num4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WinDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbLM = new System.Windows.Forms.PictureBox();
            this.rtReadMe = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgPicks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgHistory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLM)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgPicks
            // 
            this.dgPicks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPicks.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pNum1,
            this.pNum2,
            this.pNum3,
            this.pNum4,
            this.pLB,
            this.pWinDate});
            this.dgPicks.Location = new System.Drawing.Point(154, 89);
            this.dgPicks.Name = "dgPicks";
            this.dgPicks.RowTemplate.Height = 24;
            this.dgPicks.Size = new System.Drawing.Size(441, 313);
            this.dgPicks.TabIndex = 2;
            this.dgPicks.Visible = false;
            // 
            // pNum1
            // 
            this.pNum1.DataPropertyName = "Num1";
            this.pNum1.HeaderText = "Num 1";
            this.pNum1.Name = "pNum1";
            this.pNum1.Width = 80;
            // 
            // pNum2
            // 
            this.pNum2.DataPropertyName = "Num2";
            this.pNum2.HeaderText = "Num 2";
            this.pNum2.Name = "pNum2";
            this.pNum2.Width = 80;
            // 
            // pNum3
            // 
            this.pNum3.DataPropertyName = "Num3";
            this.pNum3.HeaderText = "Num 3";
            this.pNum3.Name = "pNum3";
            this.pNum3.Width = 80;
            // 
            // pNum4
            // 
            this.pNum4.DataPropertyName = "Num4";
            this.pNum4.HeaderText = "Num 4";
            this.pNum4.Name = "pNum4";
            this.pNum4.Width = 80;
            // 
            // pLB
            // 
            this.pLB.DataPropertyName = "LB";
            this.pLB.HeaderText = "LB";
            this.pLB.Name = "pLB";
            this.pLB.Width = 80;
            // 
            // pWinDate
            // 
            this.pWinDate.HeaderText = "WinDate";
            this.pWinDate.Name = "pWinDate";
            this.pWinDate.Visible = false;
            // 
            // dgHistory
            // 
            this.dgHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Num1,
            this.Num2,
            this.Num3,
            this.Num4,
            this.LB,
            this.WinDate});
            this.dgHistory.Location = new System.Drawing.Point(93, 89);
            this.dgHistory.Name = "dgHistory";
            this.dgHistory.RowTemplate.Height = 24;
            this.dgHistory.Size = new System.Drawing.Size(546, 422);
            this.dgHistory.TabIndex = 3;
            this.dgHistory.Visible = false;
            // 
            // Num1
            // 
            this.Num1.DataPropertyName = "Num1";
            this.Num1.HeaderText = "Num 1";
            this.Num1.Name = "Num1";
            this.Num1.Width = 80;
            // 
            // Num2
            // 
            this.Num2.DataPropertyName = "Num2";
            this.Num2.HeaderText = "Num 2";
            this.Num2.Name = "Num2";
            this.Num2.Width = 80;
            // 
            // Num3
            // 
            this.Num3.DataPropertyName = "Num3";
            this.Num3.HeaderText = "Num 3";
            this.Num3.Name = "Num3";
            this.Num3.Width = 80;
            // 
            // Num4
            // 
            this.Num4.DataPropertyName = "Num4";
            this.Num4.HeaderText = "Num 4";
            this.Num4.Name = "Num4";
            this.Num4.Width = 80;
            // 
            // LB
            // 
            this.LB.DataPropertyName = "LB";
            this.LB.HeaderText = "LB";
            this.LB.Name = "LB";
            this.LB.Width = 80;
            // 
            // WinDate
            // 
            this.WinDate.DataPropertyName = "WinDate";
            this.WinDate.HeaderText = "Date";
            this.WinDate.Name = "WinDate";
            this.WinDate.Width = 80;
            // 
            // pbLM
            // 
            this.pbLM.Image = ((System.Drawing.Image)(resources.GetObject("pbLM.Image")));
            this.pbLM.Location = new System.Drawing.Point(588, 12);
            this.pbLM.Name = "pbLM";
            this.pbLM.Size = new System.Drawing.Size(136, 58);
            this.pbLM.TabIndex = 6;
            this.pbLM.TabStop = false;
            // 
            // rtReadMe
            // 
            this.rtReadMe.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtReadMe.Location = new System.Drawing.Point(12, 89);
            this.rtReadMe.Name = "rtReadMe";
            this.rtReadMe.Size = new System.Drawing.Size(712, 422);
            this.rtReadMe.TabIndex = 7;
            this.rtReadMe.Text = resources.GetString("rtReadMe.Text");
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(736, 28);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(80, 24);
            this.toolStripMenuItem1.Text = "Read Me";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(120, 24);
            this.toolStripMenuItem2.Text = "Refresh Results";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(121, 24);
            this.toolStripMenuItem3.Text = "Display History";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(117, 24);
            this.toolStripMenuItem4.Text = "Generate Picks";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 549);
            this.Controls.Add(this.rtReadMe);
            this.Controls.Add(this.pbLM);
            this.Controls.Add(this.dgHistory);
            this.Controls.Add(this.dgPicks);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Florida Lottery Lucky Money Game";
            ((System.ComponentModel.ISupportInitialize)(this.dgPicks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgHistory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLM)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgPicks;
        private System.Windows.Forms.DataGridView dgHistory;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num4;
        private System.Windows.Forms.DataGridViewTextBoxColumn LB;
        private System.Windows.Forms.DataGridViewTextBoxColumn WinDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNum1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNum2;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNum3;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNum4;
        private System.Windows.Forms.DataGridViewTextBoxColumn pLB;
        private System.Windows.Forms.DataGridViewTextBoxColumn pWinDate;
        private System.Windows.Forms.PictureBox pbLM;
        private System.Windows.Forms.RichTextBox rtReadMe;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
    }
}

