﻿using System;
using System.Collections.Generic;

namespace FloridaLM
{
    public class LMNumbers
    {
        public int Num1 { get; set; }
        public int Num2 { get; set; }
        public int Num3 { get; set; }
        public int Num4 { get; set; }
        public int LB { get; set; }
        public DateTime WinDate { get; set; }
    }

}